package Soal2;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
		
		Prime prime = new Prime();
		Thread thread = new Thread(prime);
		thread.start();
		
		Fibo fibo = new Fibo();
		Thread thread2 = new Thread(fibo);
		thread2.start();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new Main();	
	}

}
