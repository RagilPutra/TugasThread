package Soal1;

public class OddEven implements Runnable {
	
	int angka;
	
	public OddEven(int angka) {
		this.angka = angka;
	}
	
	

	
	public OddEven() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		try {

			Thread.sleep(30000);
			if(angka %2 == 1){
				System.out.println("--Angka adalah Ganjil--");
			}
			else{
				System.out.println("--Angka adalah Genap--");
			}
		} catch (InterruptedException e) {
		}
	
	}

}
