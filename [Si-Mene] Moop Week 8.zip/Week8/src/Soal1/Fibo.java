package Soal1;

public class Fibo implements Runnable {

	int angka;

	public Fibo(int angka) {
		this.angka = angka;
	}
	
	public Fibo() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub

		int n = 20, angka1 = 0, angka2 = 1;
		System.out.println(n + " Angka Fibonacci Pertama: ");
		System.out.println("--------------------------");
		
		for (int i = 1; i <= n; ++i) {
			System.out.print(angka1 + " ");
			int sum = angka1 + angka2;
			angka1 = angka2;
			angka2 = sum;

			if (sum != angka1 + angka2 && angka1 != angka2 && angka2 != sum) {
				System.out.println("Bukan Fibonacci");
			} else {
				System.out.println("Fibonacci");
			}
		}
		System.out.println("=================================================================================");
		System.out.println("Jika angka yang dimasukan tidak ada, maka angka tersebut bukan bilangan Fibonacci");
		
		System.out.println("=================================================================================");
		System.out.println("Tunggu 30 detik untuk hasil genap atau ganjil");
		
	}

}
