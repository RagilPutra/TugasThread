package Soal1;
import java.util.*;
public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
		Scanner scan = new Scanner(System.in);
		int angka;
		
		System.out.print("Masukkan Angka: ");
		angka = scan.nextInt();scan.nextLine();
		System.out.println("==========================");
	
		
		Fibo Fibo1 = new Fibo(angka);
		Thread thread = new Thread(Fibo1);
		thread.start();
		

		OddEven oddEven = new OddEven(angka);
		Thread thread2 = new Thread(oddEven);
		thread2.start();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new Main();
		
	}

}
